
import cv2
import numpy as np
from moviepy.editor import VideoFileClip

def grayscale(img):
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

def canny(img, low_threshold, high_threshold):
    return cv2.Canny(img, low_threshold, high_threshold)

def gaussian_blur(img, kernel_size):
    return cv2.GaussianBlur(img, (kernel_size, kernel_size), 0)

def region_of_interest(img, vertices):
    mask = np.zeros_like(img)
    cv2.fillPoly(mask, [vertices], 255)
    masked_image = cv2.bitwise_and(img, mask)
    return masked_image

def draw_lines(img, lines):
    if lines is None:
        return img
    for line in lines:
        for x1, y1, x2, y2 in line:
            cv2.line(img, (x1, y1), (x2, y2), (255, 0, 0), 10)
    return img

def hough_lines(img):
    lines = cv2.HoughLinesP(img, 1, np.pi/180, 15, minLineLength=40, maxLineGap=20)
    line_img = np.zeros((*img.shape, 3), dtype=np.uint8)
    return draw_lines(line_img, lines)

def process_frame(frame):
    gray = grayscale(frame)
    blur = gaussian_blur(gray, 5)
    edges = canny(blur, 50, 150)
    height, width = edges.shape
    roi = region_of_interest(edges, np.array([[
        (0, height),
        (width // 2 - 50, height // 2 + 50),
        (width // 2 + 50, height // 2 + 50),
        (width, height)
    ]], dtype=np.int32))
    lines_img = hough_lines(roi)
    return cv2.addWeighted(frame, 0.8, lines_img, 1, 0)

if __name__ == "__main__":
    print("🚦 Starting lane detection script...")
    input_video = "test_video.mp4"
    output_video = "output_video.mp4"
    clip = VideoFileClip(input_video)
    processed_clip = clip.fl_image(process_frame)
    processed_clip.write_videofile(output_video, audio=False)
